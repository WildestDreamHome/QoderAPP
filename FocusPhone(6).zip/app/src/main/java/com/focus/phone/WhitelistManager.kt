package com.focus.phone

import android.content.Context
import android.content.SharedPreferences

class WhitelistManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isFocusModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_FOCUS_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_FOCUS_MODE, value).apply()

    var isSetupComplete: Boolean
        get() = prefs.getBoolean(KEY_SETUP_COMPLETE, false)
        set(value) = prefs.edit().putBoolean(KEY_SETUP_COMPLETE, value).apply()

    var isAccessibilityBlockingEnabled: Boolean
        get() = prefs.getBoolean(KEY_ACCESSIBILITY_BLOCKING, false)
        set(value) = prefs.edit().putBoolean(KEY_ACCESSIBILITY_BLOCKING, value).apply()

    fun getWhitelistedPackages(): Set<String> {
        return prefs.getStringSet(KEY_WHITELIST, defaultWhitelist()) ?: defaultWhitelist()
    }

    fun setWhitelistedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_WHITELIST, packages).apply()
    }

    fun addToWhitelist(packageName: String) {
        val current = getWhitelistedPackages().toMutableSet()
        current.add(packageName)
        setWhitelistedPackages(current)
    }

    fun removeFromWhitelist(packageName: String) {
        val current = getWhitelistedPackages().toMutableSet()
        current.remove(packageName)
        setWhitelistedPackages(current)
    }

    fun isWhitelisted(packageName: String): Boolean {
        return getWhitelistedPackages().contains(packageName)
    }

    fun getDocumentFolders(): Set<String> {
        return prefs.getStringSet(KEY_DOC_FOLDERS, defaultDocFolders()) ?: defaultDocFolders()
    }

    fun setDocumentFolders(folders: Set<String>) {
        prefs.edit().putStringSet(KEY_DOC_FOLDERS, folders).apply()
    }

    fun getDocumentFolderUris(): Set<String> {
        return prefs.getStringSet(KEY_DOC_FOLDER_URIS, emptySet()) ?: emptySet()
    }

    fun setDocumentFolderUris(uris: Set<String>) {
        prefs.edit().putStringSet(KEY_DOC_FOLDER_URIS, uris).apply()
    }

    // ========== Quote Board ==========

    fun getQuotes(): List<String> {
        val stored = prefs.getString(KEY_QUOTES, null)
        return if (stored != null) {
            stored.split("|||").filter { it.isNotBlank() }
        } else {
            defaultQuotes()
        }
    }

    fun setQuotes(quotes: List<String>) {
        prefs.edit().putString(KEY_QUOTES, quotes.joinToString("|||")).apply()
    }

    fun getRandomQuote(): String {
        val quotes = getQuotes()
        return quotes.random()
    }

    private fun defaultQuotes(): List<String> {
        return listOf(
            "今天也要加油！",
            "专注当下，做好每一件事。",
            "慢慢来，比较快。",
            "学而不思则罔，思而不学则殆。",
            "千里之行，始于足下。"
        )
    }

    // ========== Memo Storage ==========

    fun getMemos(): List<Pair<Long, String>> {
        val stored = prefs.getString(KEY_MEMOS, null) ?: return emptyList()
        if (stored.isBlank()) return emptyList()
        return stored.split(";;;").filter { it.isNotBlank() }.mapNotNull { entry ->
            val parts = entry.split("|||", limit = 2)
            if (parts.size == 2) {
                val id = parts[0].toLongOrNull() ?: return@mapNotNull null
                val text = parts[1]
                Pair(id, text)
            } else null
        }
    }

    fun addMemo(text: String) {
        val memos = getMemos().toMutableList()
        val id = System.currentTimeMillis()
        memos.add(Pair(id, text))
        saveMemos(memos)
    }

    fun deleteMemo(id: Long) {
        val memos = getMemos().toMutableList()
        memos.removeAll { it.first == id }
        saveMemos(memos)
    }

    private fun saveMemos(memos: List<Pair<Long, String>>) {
        val stored = memos.joinToString(";;;") { "${it.first}|||${it.second}" }
        prefs.edit().putString(KEY_MEMOS, stored).apply()
    }

    private fun defaultWhitelist(): Set<String> {
        return setOf(
            "com.focus.phone",
            "com.tencent.mm",
            "com.deepseek.app"
        )
    }

    private fun defaultDocFolders(): Set<String> {
        return setOf("/sdcard/Documents")
    }

    companion object {
        private const val PREFS_NAME = "focus_phone_prefs"
        private const val KEY_WHITELIST = "whitelisted_packages"
        private const val KEY_FOCUS_MODE = "focus_mode_enabled"
        private const val KEY_SETUP_COMPLETE = "setup_complete"
        private const val KEY_DOC_FOLDERS = "document_folders"
        private const val KEY_DOC_FOLDER_URIS = "document_folder_uris"
        private const val KEY_ACCESSIBILITY_BLOCKING = "accessibility_blocking_enabled"
        private const val KEY_QUOTES = "quotes"
        private const val KEY_MEMOS = "memos"
    }
}
