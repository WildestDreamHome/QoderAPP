package com.focus.phone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.focus.phone.databinding.ActivityMemoBinding

class MemoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMemoBinding
    private lateinit var whitelistManager: WhitelistManager
    private lateinit var memoAdapter: MemoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMemoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        whitelistManager = WhitelistManager(this)

        binding.btnBack.setOnClickListener {
            finish()
        }

        memoAdapter = MemoAdapter(
            onItemDelete = { memoId ->
                whitelistManager.deleteMemo(memoId)
                loadMemos()
                Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show()
            }
        )

        binding.recyclerMemos.apply {
            layoutManager = LinearLayoutManager(this@MemoActivity)
            adapter = memoAdapter
        }

        binding.fabAddMemo.setOnClickListener {
            showAddMemoDialog()
        }

        loadMemos()
    }

    private fun loadMemos() {
        val memos = whitelistManager.getMemos()
            .sortedByDescending { it.first } // newest first

        memoAdapter.submitMemos(memos)

        if (memos.isEmpty()) {
            binding.tvEmpty.visibility = View.VISIBLE
            binding.recyclerMemos.visibility = View.GONE
        } else {
            binding.tvEmpty.visibility = View.GONE
            binding.recyclerMemos.visibility = View.VISIBLE
        }
    }

    private fun showAddMemoDialog() {
        val editText = EditText(this).apply {
            setTextColor(getColor(R.color.text_primary))
            hint = "输入备忘录内容"
            setHintTextColor(getColor(R.color.text_hint))
            setPadding(48, 32, 48, 32)
            minLines = 3
            gravity = android.view.Gravity.TOP
        }

        AlertDialog.Builder(this, R.style.Theme_FocusPhone_Dialog)
            .setTitle("新建备忘录")
            .setView(editText)
            .setPositiveButton("保存") { _, _ ->
                val text = editText.text.toString().trim()
                if (text.isNotBlank()) {
                    whitelistManager.addMemo(text)
                    loadMemos()
                    Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "内容不能为空", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // Adapter for memo list
    inner class MemoAdapter(
        private val onItemDelete: (Long) -> Unit
    ) : RecyclerView.Adapter<MemoAdapter.MemoViewHolder>() {

        private var memos: List<Pair<Long, String>> = emptyList()

        fun submitMemos(newMemos: List<Pair<Long, String>>) {
            memos = newMemos
            notifyDataSetChanged()
        }

        inner class MemoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvText: TextView = view.findViewById(R.id.tvMemoText)
            val btnDelete: ImageButton = view.findViewById(R.id.btnDeleteMemo)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MemoViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_memo, parent, false)
            return MemoViewHolder(view)
        }

        override fun onBindViewHolder(holder: MemoViewHolder, position: Int) {
            val memo = memos[position]
            holder.tvText.text = memo.second
            holder.btnDelete.setOnClickListener {
                onItemDelete(memo.first)
            }
        }

        override fun getItemCount() = memos.size
    }
}
