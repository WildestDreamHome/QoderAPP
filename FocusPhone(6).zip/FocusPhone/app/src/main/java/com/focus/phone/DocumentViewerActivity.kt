package com.focus.phone

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import com.focus.phone.databinding.ActivityDocumentViewerBinding
import java.io.File
import java.io.InputStream

class DocumentViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDocumentViewerBinding
    private lateinit var whitelistManager: WhitelistManager
    private var pdfRenderer: PdfRenderer? = null
    private var pageDescriptor: ParcelFileDescriptor? = null
    private var currentPageIndex = 0
    private var totalPages = 0
    private var currentFileUri: Uri? = null
    private var currentFileName: String = ""

    // Navigation state for subfolder browsing
    private var currentTreeUri: Uri? = null
    private var currentDocDir: DocumentFile? = null
    private var currentFilePath: File? = null
    private val navigationStack = mutableListOf<NavigationEntry>()

    // Selection mode state
    private var isSelectionMode = false
    private val selectedItems = mutableSetOf<Int>()
    private var currentFiles = mutableListOf<DocFileInfo>()
    private var currentAdapter: DocFileListAdapter? = null

    data class NavigationEntry(
        val treeUri: Uri?,
        val docDir: DocumentFile?,
        val filePath: File?,
        val displayName: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        whitelistManager = WhitelistManager(this)

        setupFileList()

        binding.btnBack.setOnClickListener {
            if (isSelectionMode) {
                exitSelectionMode()
            } else if (navigationStack.isNotEmpty()) {
                navigateUp()
            } else {
                finish()
            }
        }

        binding.btnRefresh.setOnClickListener {
            refreshCurrentView()
        }

        binding.btnNewFolder.setOnClickListener {
            showNewFolderDialog()
        }

        binding.btnUpDir.setOnClickListener {
            navigateUp()
        }

        // Selection action bar buttons
        binding.btnSelectAll.setOnClickListener {
            selectAllItems()
        }

        binding.btnMove.setOnClickListener {
            showMoveDialog()
        }

        binding.btnDelete.setOnClickListener {
            showDeleteConfirmation()
        }

        binding.btnCancel.setOnClickListener {
            exitSelectionMode()
        }
    }

    private fun refreshCurrentView() {
        exitSelectionMode()
        if (navigationStack.isEmpty()) {
            setupFileList()
        } else {
            loadCurrentDirectory()
        }
    }

    private fun setupFileList() {
        exitSelectionMode()
        navigationStack.clear()
        currentTreeUri = null
        currentDocDir = null
        currentFilePath = null
        updateBreadcrumb()

        val files = mutableListOf<DocFileInfo>()
        val folderUris = whitelistManager.getDocumentFolderUris()

        for (uriString in folderUris) {
            try {
                val treeUri = Uri.parse(uriString)
                val docTree = DocumentFile.fromTreeUri(this, treeUri) ?: continue
                scanDirectory(docTree, files)
            } catch (e: Exception) {
                // Skip invalid URIs
            }
        }

        // Only scan common file paths as fallback if no URI folders are selected
        if (folderUris.isEmpty()) {
            val commonPaths = listOf(
                File("/sdcard/Documents"),
                File("/sdcard/Download")
            )
            for (path in commonPaths) {
                if (path.exists() && path.isDirectory) {
                    val pathFiles = path.listFiles { file ->
                        file.isFile && (file.extension.lowercase() in listOf("pdf", "doc", "docx", "txt", "md"))
                    }
                    if (pathFiles != null) {
                        for (f in pathFiles) {
                            if (files.none { it.name == f.name }) {
                                files.add(DocFileInfo(f.name, f.length(), f.extension.lowercase(), Uri.fromFile(f), f, false))
                            }
                        }
                    }
                    // Also add subdirectories
                    val subdirs = path.listFiles { file -> file.isDirectory }
                    if (subdirs != null) {
                        for (d in subdirs) {
                            if (files.none { it.name == d.name && it.isDirectory }) {
                                files.add(DocFileInfo(d.name, 0L, "", Uri.fromFile(d), d, true))
                            }
                        }
                    }
                }
            }
        }

        displayFileList(files)
    }

    private fun navigateIntoDirectory(fileInfo: DocFileInfo) {
        // Save current state
        val currentEntry = NavigationEntry(
            currentTreeUri, currentDocDir, currentFilePath,
            currentDocDir?.name ?: currentFilePath?.name ?: "根目录"
        )
        navigationStack.add(currentEntry)

        if (fileInfo.file != null && fileInfo.file.isDirectory) {
            // File-based navigation
            currentFilePath = fileInfo.file
            currentTreeUri = null
            currentDocDir = null
        } else if (fileInfo.uri != null) {
            // URI-based navigation (SAF)
            try {
                val docDir = DocumentFile.fromTreeUri(this, fileInfo.uri)
                currentDocDir = docDir
                currentTreeUri = fileInfo.uri
                currentFilePath = null
            } catch (e: Exception) {
                Toast.makeText(this, "无法进入文件夹: ${e.message}", Toast.LENGTH_SHORT).show()
                navigationStack.removeLastOrNull()
                return
            }
        }

        loadCurrentDirectory()
    }

    private fun loadCurrentDirectory() {
        exitSelectionMode()
        val files = mutableListOf<DocFileInfo>()

        if (currentDocDir != null) {
            // SAF directory
            scanDirectory(currentDocDir!!, files)
        } else if (currentFilePath != null) {
            // File-based directory
            val dir = currentFilePath!!
            if (dir.exists() && dir.isDirectory) {
                val children = dir.listFiles()
                if (children != null) {
                    for (child in children) {
                        if (child.isDirectory) {
                            files.add(DocFileInfo(child.name, 0L, "", Uri.fromFile(child), child, true))
                        } else if (child.isFile) {
                            val ext = child.extension.lowercase()
                            if (ext in listOf("pdf", "doc", "docx", "txt", "md")) {
                                files.add(DocFileInfo(child.name, child.length(), ext, Uri.fromFile(child), child, false))
                            }
                        }
                    }
                }
            }
        }

        displayFileList(files)
        updateBreadcrumb()
    }

    private fun displayFileList(files: MutableList<DocFileInfo>) {
        files.sortWith(compareByDescending<DocFileInfo> { it.isDirectory }.thenByDescending { it.lastModified ?: 0L })
        currentFiles = files

        if (files.isEmpty()) {
            binding.tvNoFiles.visibility = View.VISIBLE
            binding.recyclerFiles.visibility = View.GONE
            currentAdapter = null
        } else {
            binding.tvNoFiles.visibility = View.GONE
            binding.recyclerFiles.visibility = View.VISIBLE

            binding.recyclerFiles.layoutManager = LinearLayoutManager(this)
            currentAdapter = DocFileListAdapter(files,
                onClick = { fileInfo ->
                    if (isSelectionMode) {
                        val pos = files.indexOf(fileInfo)
                        if (pos >= 0) toggleItemSelection(pos)
                    } else if (fileInfo.isDirectory) {
                        navigateIntoDirectory(fileInfo)
                    } else {
                        openFile(fileInfo)
                    }
                },
                onLongClick = { _, position ->
                    if (!isSelectionMode) {
                        enterSelectionMode()
                        toggleItemSelection(position)
                    }
                }
            )
            binding.recyclerFiles.adapter = currentAdapter
        }
    }

    private fun navigateUp() {
        if (navigationStack.isNotEmpty()) {
            val prev = navigationStack.removeLast()
            currentTreeUri = prev.treeUri
            currentDocDir = prev.docDir
            currentFilePath = prev.filePath
            loadCurrentDirectory()
        }
    }

    private fun updateBreadcrumb() {
        if (navigationStack.isEmpty()) {
            binding.breadcrumbContainer.visibility = View.GONE
        } else {
            binding.breadcrumbContainer.visibility = View.VISIBLE
            val pathParts = mutableListOf("根目录")
            for (entry in navigationStack) {
                pathParts.add(entry.displayName)
            }
            val currentName = currentDocDir?.name ?: currentFilePath?.name ?: ""
            if (currentName.isNotBlank()) {
                pathParts.add(currentName)
            }
            binding.tvBreadcrumb.text = pathParts.joinToString(" / ")
        }
    }

    // ==================== Selection Mode ====================

    private fun enterSelectionMode() {
        isSelectionMode = true
        selectedItems.clear()
        binding.selectionActionBar.visibility = View.VISIBLE
        currentAdapter?.setSelectionMode(true)
    }

    private fun exitSelectionMode() {
        isSelectionMode = false
        selectedItems.clear()
        binding.selectionActionBar.visibility = View.GONE
        currentAdapter?.setSelectionMode(false)
    }

    private fun toggleItemSelection(position: Int) {
        if (selectedItems.contains(position)) {
            selectedItems.remove(position)
        } else {
            selectedItems.add(position)
        }
        currentAdapter?.setSelected(position, selectedItems.contains(position))

        if (selectedItems.isEmpty()) {
            exitSelectionMode()
        }
    }

    private fun selectAllItems() {
        selectedItems.clear()
        for (i in currentFiles.indices) {
            selectedItems.add(i)
        }
        currentAdapter?.selectAll()
    }

    // ==================== Delete ====================

    private fun showDeleteConfirmation() {
        val count = selectedItems.size
        if (count == 0) return

        AlertDialog.Builder(this, R.style.Theme_FocusPhone_Dialog)
            .setTitle("确认删除")
            .setMessage("确定要删除选中的 $count 个文件/文件夹吗？")
            .setPositiveButton("删除") { _, _ ->
                performDelete()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun performDelete() {
        var deletedCount = 0
        val positions = selectedItems.sortedDescending()

        for (pos in positions) {
            if (pos < 0 || pos >= currentFiles.size) continue
            val fileInfo = currentFiles[pos]
            try {
                if (fileInfo.file != null) {
                    // File-based deletion
                    val success = if (fileInfo.file.isDirectory) {
                        fileInfo.file.deleteRecursively()
                    } else {
                        fileInfo.file.delete()
                    }
                    if (success) deletedCount++
                } else if (fileInfo.uri != null) {
                    // SAF-based deletion
                    val docFile = DocumentFile.fromSingleUri(this, fileInfo.uri)
                    if (docFile != null && docFile.exists()) {
                        if (docFile.delete()) deletedCount++
                    } else {
                        // Try fromTreeUri for directory items
                        val docTree = DocumentFile.fromTreeUri(this, fileInfo.uri)
                        if (docTree != null && docTree.exists()) {
                            if (docTree.delete()) deletedCount++
                        }
                    }
                }
            } catch (e: Exception) {
                // Skip items that fail to delete
            }
        }

        Toast.makeText(this, "已删除 $deletedCount 个文件", Toast.LENGTH_SHORT).show()
        exitSelectionMode()
        if (navigationStack.isEmpty()) {
            setupFileList()
        } else {
            loadCurrentDirectory()
        }
    }

    // ==================== Move ====================

    private fun showMoveDialog() {
        if (selectedItems.isEmpty()) return

        // Check if any SAF items are selected
        val hasSafItems = selectedItems.any { pos ->
            pos in currentFiles.indices && currentFiles[pos].file == null
        }

        // Build list of subfolders in current directory
        val folders = mutableListOf<Pair<String, Any>>() // name -> File or DocumentFile
        folders.add("返回上级" to Unit)

        if (currentDocDir != null) {
            // SAF-based directory
            val children = currentDocDir?.listFiles() ?: emptyArray()
            for (child in children) {
                if (child.isDirectory) {
                    val name = child.name ?: continue
                    folders.add(name to child)
                }
            }
        } else if (currentFilePath != null) {
            // File-based directory
            val children = currentFilePath?.listFiles() ?: emptyArray()
            for (child in children) {
                if (child.isDirectory) {
                    folders.add(child.name to child)
                }
            }
        }

        val folderNames = folders.map { it.first }.toTypedArray()

        AlertDialog.Builder(this, R.style.Theme_FocusPhone_Dialog)
            .setTitle("移动到文件夹")
            .setItems(folderNames) { _, which ->
                val target = folders[which]
                if (target.first == "返回上级") {
                    moveToParent(hasSafItems)
                } else {
                    moveToFolder(target.second, target.first, hasSafItems)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun moveToParent(hasSafItems: Boolean) {
        if (hasSafItems) {
            Toast.makeText(this, "SAF文件暂不支持移动，请用文件管理器操作", Toast.LENGTH_LONG).show()
            exitSelectionMode()
            return
        }

        val targetDir: File = when {
            currentFilePath != null -> currentFilePath?.parentFile ?: run {
                Toast.makeText(this, "无法返回上级目录", Toast.LENGTH_SHORT).show()
                return
            }
            else -> {
                Toast.makeText(this, "无法返回上级目录", Toast.LENGTH_SHORT).show()
                return
            }
        }

        performMoveFileBased(targetDir, hasSafItems)
    }

    private fun moveToFolder(target: Any, targetName: String, hasSafItems: Boolean) {
        if (hasSafItems) {
            Toast.makeText(this, "SAF文件暂不支持移动，请用文件管理器操作", Toast.LENGTH_LONG).show()
            exitSelectionMode()
            return
        }

        val targetDir: File = when (target) {
            is File -> target
            is DocumentFile -> {
                Toast.makeText(this, "SAF文件暂不支持移动，请用文件管理器操作", Toast.LENGTH_LONG).show()
                exitSelectionMode()
                return
            }
            else -> return
        }

        performMoveFileBased(targetDir, hasSafItems)
    }

    private fun performMoveFileBased(targetDir: File, hasSafItems: Boolean) {
        var movedCount = 0
        val positions = selectedItems.sortedDescending()

        for (pos in positions) {
            if (pos < 0 || pos >= currentFiles.size) continue
            val fileInfo = currentFiles[pos]

            if (fileInfo.file == null) {
                // SAF item - skip
                continue
            }

            try {
                val sourceFile = fileInfo.file
                val destFile = File(targetDir, sourceFile.name)
                if (sourceFile.renameTo(destFile)) {
                    movedCount++
                }
            } catch (e: Exception) {
                // Skip items that fail to move
            }
        }

        Toast.makeText(this, "已移动 $movedCount 个文件", Toast.LENGTH_SHORT).show()
        exitSelectionMode()
        if (navigationStack.isEmpty()) {
            setupFileList()
        } else {
            loadCurrentDirectory()
        }
    }

    // ==================== Existing Functionality ====================

    private fun showNewFolderDialog() {
        val editText = EditText(this).apply {
            setTextColor(getColor(R.color.text_primary))
            hint = "输入文件夹名称"
            setHintTextColor(getColor(R.color.text_hint))
            setPadding(48, 32, 48, 32)
        }

        AlertDialog.Builder(this, R.style.Theme_FocusPhone_Dialog)
            .setTitle("新建文件夹")
            .setView(editText)
            .setPositiveButton("创建") { _, _ ->
                val name = editText.text.toString().trim()
                if (name.isNotBlank()) {
                    createFolder(name)
                } else {
                    Toast.makeText(this, "文件夹名称不能为空", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun createFolder(name: String) {
        try {
            if (currentDocDir != null) {
                // SAF-based folder creation
                val newDir = currentDocDir!!.createDirectory(name)
                if (newDir != null) {
                    Toast.makeText(this, "文件夹「$name」已创建", Toast.LENGTH_SHORT).show()
                    loadCurrentDirectory()
                } else {
                    Toast.makeText(this, "创建失败，请检查权限", Toast.LENGTH_SHORT).show()
                }
            } else if (currentFilePath != null) {
                // File-based folder creation
                val newDir = File(currentFilePath, name)
                if (newDir.mkdirs()) {
                    Toast.makeText(this, "文件夹「$name」已创建", Toast.LENGTH_SHORT).show()
                    loadCurrentDirectory()
                } else {
                    Toast.makeText(this, "创建失败，请检查权限", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Create in default Documents folder
                val defaultDir = File("/sdcard/Documents", name)
                if (defaultDir.mkdirs()) {
                    Toast.makeText(this, "文件夹「$name」已创建", Toast.LENGTH_SHORT).show()
                    setupFileList()
                } else {
                    Toast.makeText(this, "创建失败，请检查权限", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "创建失败: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scanDirectory(dir: DocumentFile, files: MutableList<DocFileInfo>) {
        val children = dir.listFiles() ?: return
        for (child in children) {
            if (child.isDirectory) {
                val name = child.name ?: continue
                files.add(DocFileInfo(name, 0L, "", child.uri, null, true))
            } else if (child.isFile) {
                val name = child.name ?: continue
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in listOf("pdf", "doc", "docx", "txt", "md")) {
                    files.add(DocFileInfo(name, child.length(), ext, child.uri, null, false))
                }
            }
        }
    }

    private fun openFile(fileInfo: DocFileInfo) {
        currentFileUri = fileInfo.uri
        currentFileName = fileInfo.name
        when (fileInfo.extension) {
            "pdf" -> openPdf(fileInfo)
            "doc", "docx" -> openWord(fileInfo)
            "txt", "md" -> openText(fileInfo)
            else -> Toast.makeText(this, "不支持的文件格式", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPdf(fileInfo: DocFileInfo) {
        // First try to open with external PDF viewer (WPS, Adobe, etc.)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileInfo.uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // No external PDF viewer, fall back to built-in renderer
            openPdfBuiltIn(fileInfo)
        }
    }

    private fun openPdfBuiltIn(fileInfo: DocFileInfo) {
        try {
            val pfd = contentResolver.openFileDescriptor(fileInfo.uri, "r") ?: return
            pageDescriptor = pfd
            pdfRenderer = PdfRenderer(pfd)
            totalPages = pdfRenderer!!.pageCount
            currentPageIndex = 0

            binding.pdfContainer.visibility = View.VISIBLE
            binding.recyclerFiles.visibility = View.GONE
            binding.tvNoFiles.visibility = View.GONE
            binding.pdfControls.visibility = View.VISIBLE

            renderPage(currentPageIndex)

            binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"

            binding.btnPrevPage.setOnClickListener {
                if (currentPageIndex > 0) {
                    currentPageIndex--
                    renderPage(currentPageIndex)
                    binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"
                }
            }

            binding.btnNextPage.setOnClickListener {
                if (currentPageIndex < totalPages - 1) {
                    currentPageIndex++
                    renderPage(currentPageIndex)
                    binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"
                }
            }

            binding.btnClosePdf.setOnClickListener {
                closePdf()
                binding.pdfContainer.visibility = View.GONE
                binding.pdfControls.visibility = View.GONE
                binding.recyclerFiles.visibility = View.VISIBLE
            }

            binding.tvPdfFileName.text = fileInfo.name

        } catch (e: Exception) {
            Toast.makeText(this, "无法打开PDF，请安装WPS等PDF阅读器", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderPage(index: Int) {
        pdfRenderer?.let { renderer ->
            val page = renderer.openPage(index)
            val density = resources.displayMetrics.density
            val width = (page.width * density).toInt()
            val height = (page.height * density).toInt()
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            binding.ivPdfPage.setImageBitmap(bitmap)
        }
    }

    private fun closePdf() {
        pdfRenderer?.close()
        pageDescriptor?.close()
        pdfRenderer = null
        pageDescriptor = null
    }

    private fun openWord(fileInfo: DocFileInfo) {
        val mime = when (fileInfo.extension) {
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "application/octet-stream"
        }

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileInfo.uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            extractTextFallback(fileInfo)
        }
    }

    private fun openText(fileInfo: DocFileInfo) {
        try {
            val inputStream = contentResolver.openInputStream(fileInfo.uri) ?: return
            val content = inputStream.bufferedReader().readText()
            inputStream.close()

            binding.textContainer.visibility = View.VISIBLE
            binding.recyclerFiles.visibility = View.GONE
            binding.tvNoFiles.visibility = View.GONE
            binding.tvTextContent.text = content
            binding.tvFileName.text = fileInfo.name

            binding.btnCloseText.setOnClickListener {
                binding.textContainer.visibility = View.GONE
                binding.recyclerFiles.visibility = View.VISIBLE
            }
        } catch (e: Exception) {
            Toast.makeText(this, "无法读取文件: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractTextFallback(fileInfo: DocFileInfo) {
        try {
            val inputStream = contentResolver.openInputStream(fileInfo.uri) ?: return
            val bytes = inputStream.readBytes()
            inputStream.close()

            val zipFile = java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes))
            var entry = zipFile.nextEntry
            var xmlContent: String? = null
            while (entry != null) {
                if (entry.name == "word/document.xml") {
                    xmlContent = zipFile.bufferedReader().readText()
                    break
                }
                entry = zipFile.nextEntry
            }
            zipFile.close()

            if (xmlContent != null) {
                val text = xmlContent.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
                binding.textContainer.visibility = View.VISIBLE
                binding.recyclerFiles.visibility = View.GONE
                binding.tvNoFiles.visibility = View.GONE
                binding.tvTextContent.text = text
                binding.tvFileName.text = fileInfo.name

                binding.btnCloseText.setOnClickListener {
                    binding.textContainer.visibility = View.GONE
                    binding.recyclerFiles.visibility = View.VISIBLE
                }
            } else {
                Toast.makeText(this, "无法提取文档内容，请安装WPS等办公应用", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "无法提取文档内容: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onBackPressed() {
        if (isSelectionMode) {
            exitSelectionMode()
        } else if (navigationStack.isNotEmpty()) {
            navigateUp()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        closePdf()
    }
}

// Data class for document file info
data class DocFileInfo(
    val name: String,
    val size: Long,
    val extension: String,
    val uri: Uri,
    val file: File? = null,
    val isDirectory: Boolean = false,
    val lastModified: Long? = null
)

// File list adapter with selection mode support
class DocFileListAdapter(
    private val files: List<DocFileInfo>,
    private val onClick: (DocFileInfo) -> Unit,
    private val onLongClick: (DocFileInfo, Int) -> Unit = { _, _ -> }
) : androidx.recyclerview.widget.RecyclerView.Adapter<DocFileListAdapter.ViewHolder>() {

    private var selectionMode = false
    private val selectedPositions = mutableSetOf<Int>()

    class ViewHolder(view: View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(view) {
        val tvName: android.widget.TextView = view.findViewById(R.id.tvFileName)
        val tvSize: android.widget.TextView = view.findViewById(R.id.tvFileSize)
        val tvType: android.widget.TextView = view.findViewById(R.id.tvFileType)
        val ivIcon: android.widget.ImageView = view.findViewById(R.id.ivFileIcon)
        val cbSelect: CheckBox = view.findViewById(R.id.cbSelect)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_file, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = files[position]
        holder.tvName.text = file.name

        if (file.isDirectory) {
            holder.tvSize.text = "文件夹"
            holder.tvType.text = ""
            holder.ivIcon.setImageResource(android.R.drawable.ic_menu_sort_by_size)
            holder.ivIcon.setColorFilter(holder.itemView.context.getColor(R.color.accent))
        } else {
            holder.tvSize.text = formatFileSize(file.size)
            holder.tvType.text = file.extension.uppercase()
            holder.ivIcon.setImageResource(R.drawable.ic_document)
            holder.ivIcon.clearColorFilter()
        }

        // Selection mode: show/hide checkbox
        holder.cbSelect.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.cbSelect.isChecked = selectedPositions.contains(position)
        holder.cbSelect.setOnCheckedChangeListener(null)
        holder.cbSelect.isChecked = selectedPositions.contains(position)
        holder.cbSelect.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedPositions.add(position)
            } else {
                selectedPositions.remove(position)
            }
        }

        holder.itemView.setOnClickListener { onClick(file) }
        holder.itemView.setOnLongClickListener {
            onLongClick(file, position)
            true
        }
    }

    override fun getItemCount() = files.size

    fun setSelectionMode(enabled: Boolean) {
        selectionMode = enabled
        if (!enabled) {
            selectedPositions.clear()
        }
        notifyDataSetChanged()
    }

    fun setSelected(position: Int, selected: Boolean) {
        if (selected) {
            selectedPositions.add(position)
        } else {
            selectedPositions.remove(position)
        }
        notifyItemChanged(position)
    }

    fun selectAll() {
        for (i in files.indices) {
            selectedPositions.add(i)
        }
        notifyDataSetChanged()
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> "${bytes / (1024 * 1024)} MB"
        }
    }
}
