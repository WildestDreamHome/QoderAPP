package com.focus.phone

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.focus.phone.databinding.ActivityDocumentViewerBinding
import java.io.File

class DocumentViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDocumentViewerBinding
    private lateinit var whitelistManager: WhitelistManager
    private var pdfRenderer: PdfRenderer? = null
    private var pageDescriptor: ParcelFileDescriptor? = null
    private var currentPageIndex = 0
    private var totalPages = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        whitelistManager = WhitelistManager(this)

        setupFileList()

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnRefresh.setOnClickListener {
            setupFileList()
        }
    }

    private fun setupFileList() {
        val files = mutableListOf<File>()
        val folders = whitelistManager.getDocumentFolders()

        for (folderPath in folders) {
            val folder = File(folderPath)
            if (folder.exists() && folder.isDirectory) {
                val folderFiles = folder.listFiles { file ->
                    file.isFile && (file.extension.lowercase() in listOf("pdf", "doc", "docx", "txt", "md"))
                }
                if (folderFiles != null) {
                    files.addAll(folderFiles)
                }
            }
        }

        // Also scan common locations
        val commonPaths = listOf(
            File("/sdcard/Documents"),
            File("/sdcard/Download"),
            getExternalFilesDir(null)
        )

        for (path in commonPaths) {
            if (path != null && path.exists() && path.isDirectory) {
                val pathFiles = path.listFiles { file ->
                    file.isFile && (file.extension.lowercase() in listOf("pdf", "doc", "docx", "txt", "md"))
                }
                if (pathFiles != null) {
                    for (f in pathFiles) {
                        if (!files.contains(f)) {
                            files.add(f)
                        }
                    }
                }
            }
        }

        files.sortByDescending { it.lastModified() }

        if (files.isEmpty()) {
            binding.tvNoFiles.visibility = android.view.View.VISIBLE
            binding.recyclerFiles.visibility = android.view.View.GONE
        } else {
            binding.tvNoFiles.visibility = android.view.View.GONE
            binding.recyclerFiles.visibility = android.view.View.VISIBLE

            binding.recyclerFiles.layoutManager = LinearLayoutManager(this)
            binding.recyclerFiles.adapter = FileListAdapter(files) { file ->
                openFile(file)
            }
        }
    }

    private fun openFile(file: File) {
        when (file.extension.lowercase()) {
            "pdf" -> openPdf(file)
            "doc", "docx" -> openWord(file)
            "txt", "md" -> openText(file)
            else -> Toast.makeText(this, "不支持的文件格式", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPdf(file: File) {
        try {
            // Use built-in PdfRenderer
            pageDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pdfRenderer = PdfRenderer(pageDescriptor!!)
            totalPages = pdfRenderer!!.pageCount
            currentPageIndex = 0

            binding.pdfContainer.visibility = android.view.View.VISIBLE
            binding.recyclerFiles.visibility = android.view.View.GONE
            binding.tvNoFiles.visibility = android.view.View.GONE
            binding.pdfControls.visibility = android.view.View.VISIBLE

            renderPage(currentPageIndex)

            binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"

            binding.btnPrevPage.setOnClickListener {
                if (currentPageIndex > 0) {
                    currentPageIndex--
                    renderPage(currentPageIndex)
                    binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"
                }
            }

            binding.btnNextPage.setOnClickListener {
                if (currentPageIndex < totalPages - 1) {
                    currentPageIndex++
                    renderPage(currentPageIndex)
                    binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"
                }
            }

            binding.btnClosePdf.setOnClickListener {
                closePdf()
                binding.pdfContainer.visibility = android.view.View.GONE
                binding.pdfControls.visibility = android.view.View.GONE
                binding.recyclerFiles.visibility = android.view.View.VISIBLE
            }

            binding.tvPdfFileName.text = file.name

        } catch (e: Exception) {
            Toast.makeText(this, "无法打开PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderPage(index: Int) {
        pdfRenderer?.let { renderer ->
            val page = renderer.openPage(index)
            val bitmap = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            binding.ivPdfPage.setImageBitmap(bitmap)
        }
    }

    private fun closePdf() {
        pdfRenderer?.close()
        pageDescriptor?.close()
        pdfRenderer = null
        pageDescriptor = null
    }

    private fun openWord(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val mime = when (file.extension.lowercase()) {
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "application/octet-stream"
        }

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // Fallback: try to extract text
            extractTextFallback(file)
        }
    }

    private fun openText(file: File) {
        try {
            val content = file.readText()
            binding.textContainer.visibility = android.view.View.VISIBLE
            binding.recyclerFiles.visibility = android.view.View.GONE
            binding.tvNoFiles.visibility = android.view.View.GONE
            binding.tvTextContent.text = content
            binding.tvFileName.text = file.name

            binding.btnCloseText.setOnClickListener {
                binding.textContainer.visibility = android.view.View.GONE
                binding.recyclerFiles.visibility = android.view.View.VISIBLE
            }
        } catch (e: Exception) {
            Toast.makeText(this, "无法读取文件: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractTextFallback(file: File) {
        try {
            // Simple text extraction for DOCX (which is a ZIP containing XML)
            val zipFile = java.util.zip.ZipFile(file)
            val entry = zipFile.getEntry("word/document.xml")
            if (entry != null) {
                val xml = zipFile.getInputStream(entry).bufferedReader().readText()
                // Strip XML tags to get plain text
                val text = xml.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
                zipFile.close()

                binding.textContainer.visibility = android.view.View.VISIBLE
                binding.recyclerFiles.visibility = android.view.View.GONE
                binding.tvNoFiles.visibility = android.view.View.GONE
                binding.tvTextContent.text = text
                binding.tvFileName.text = file.name

                binding.btnCloseText.setOnClickListener {
                    binding.textContainer.visibility = android.view.View.GONE
                    binding.recyclerFiles.visibility = android.view.View.VISIBLE
                }
            } else {
                zipFile.close()
                Toast.makeText(this, "无法提取文档内容，请安装WPS等办公应用", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "无法提取文档内容: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        closePdf()
    }
}

// File list adapter
class FileListAdapter(
    private val files: List<File>,
    private val onClick: (File) -> Unit
) : androidx.recyclerview.widget.RecyclerView.Adapter<FileListAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(view) {
        val tvName: android.widget.TextView = view.findViewById(R.id.tvFileName)
        val tvSize: android.widget.TextView = view.findViewById(R.id.tvFileSize)
        val tvType: android.widget.TextView = view.findViewById(R.id.tvFileType)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_file, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = files[position]
        holder.tvName.text = file.name
        holder.tvSize.text = formatFileSize(file.length())
        holder.tvType.text = file.extension.uppercase()
        holder.itemView.setOnClickListener { onClick(file) }
    }

    override fun getItemCount() = files.size

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> "${bytes / (1024 * 1024)} MB"
        }
    }
}
