package com.focus.phone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class FocusAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var whitelistManager: WhitelistManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        whitelistManager = WhitelistManager(this)

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!whitelistManager.isFocusModeEnabled) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowChanged(event)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                handleContentChanged(event)
            }
        }
    }

    private fun handleWindowChanged(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return
        val className = event.className?.toString() ?: return

        // Allow our own app
        if (packageName == "com.focus.phone") return

        // Allow system UI
        if (packageName == "com.android.systemui" || packageName == "android") return

        // Check if whitelisted
        if (!whitelistManager.isWhitelisted(packageName)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            handler.post {
                Toast.makeText(this, "该应用已被屏蔽", Toast.LENGTH_SHORT).show()
            }
            return
        }

        // WeChat-specific blocking
        if (packageName == "com.tencent.mm") {
            handler.postDelayed({
                checkWeChatContent(className)
            }, 300)
        }
    }

    private fun handleContentChanged(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return
        if (packageName != "com.tencent.mm") return
        if (!whitelistManager.isFocusModeEnabled) return

        val className = event.className?.toString() ?: ""
        checkWeChatContent(className)

        // Also check the view hierarchy for keywords
        val rootNode = rootInActiveWindow ?: return
        if (containsBlockedWeChatContent(rootNode)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            handler.post {
                Toast.makeText(this, "微信娱乐功能已被屏蔽", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkWeChatContent(className: String) {
        val blockedActivities = listOf(
            "Finder",
            "Timeline",
            "sns",
            "channel",
            "feed",
            "SnsTimeLineUI",
            "FinderFeedDetailUI",
            "FinderLikeUI",
            "SnsUserUI",
            "FinderMvDetailUI",
            "channels"
        )

        for (blocked in blockedActivities) {
            if (className.contains(blocked, ignoreCase = true)) {
                performGlobalAction(GLOBAL_ACTION_BACK)
                handler.post {
                    Toast.makeText(this, "微信娱乐功能已被屏蔽", Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    private fun containsBlockedWeChatContent(node: AccessibilityNodeInfo): Boolean {
        val blockedKeywords = listOf("视频号", "朋友圈", "直播", "channels", "finder", "timeline", "sns")

        // Check node text
        val text = node.text?.toString() ?: ""
        val contentDesc = node.contentDescription?.toString() ?: ""
        val className = node.className?.toString() ?: ""

        for (keyword in blockedKeywords) {
            if (text.contains(keyword, ignoreCase = true) ||
                contentDesc.contains(keyword, ignoreCase = true) ||
                className.contains(keyword, ignoreCase = true)) {
                return true
            }
        }

        // Recurse into children
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (containsBlockedWeChatContent(child)) {
                child.recycle()
                return true
            }
            child.recycle()
        }

        return false
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    companion object {
        var instance: FocusAccessibilityService? = null
            private set
    }
}
