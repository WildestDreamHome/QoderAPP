package com.focus.phone

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.focus.phone.databinding.ActivityLauncherBinding
import com.focus.phone.databinding.DialogSettingsBinding

class LauncherActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var whitelistManager: WhitelistManager
    private lateinit var gestureDetector: GestureDetector
    private var appAdapter: AppAdapter? = null

    data class AppInfo(
        val packageName: String,
        val appName: String,
        val icon: Drawable?
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        whitelistManager = WhitelistManager(this)

        if (!whitelistManager.isFocusModeEnabled) {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        setupGestureDetector()
        loadWhitelistedApps()
    }

    override fun onResume() {
        super.onResume()
        loadWhitelistedApps()
    }

    private fun setupGestureDetector() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                showSettingsDialog()
            }
        })

        binding.root.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }

        // Also allow long-press on empty areas
        binding.recyclerApps.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            false
        }
    }

    private fun loadWhitelistedApps() {
        val pm = packageManager
        val whitelisted = whitelistManager.getWhitelistedPackages()
        val apps = mutableListOf<AppInfo>()

        for (pkg in whitelisted) {
            if (pkg == "com.focus.phone") continue
            try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                val label = pm.getApplicationLabel(appInfo).toString()
                val icon = pm.getApplicationIcon(appInfo)
                apps.add(AppInfo(pkg, label, icon))
            } catch (_: PackageManager.NameNotFoundException) {
                // App not installed, skip
            }
        }

        // Add document viewer entry
        apps.add(AppInfo("document_viewer", "文档查看器", getDrawable(R.drawable.ic_document)))

        appAdapter = AppAdapter(apps) { appInfo ->
            if (appInfo.packageName == "document_viewer") {
                openDocumentViewer()
            } else {
                launchApp(appInfo.packageName)
            }
        }

        binding.recyclerApps.apply {
            layoutManager = GridLayoutManager(this@LauncherActivity, 4)
            adapter = appAdapter
        }

        binding.tvTime.text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date())
        binding.tvDate.text = java.text.SimpleDateFormat("yyyy年M月d日 EEEE", java.util.Locale.CHINESE)
            .format(java.util.Date())
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "无法启动应用", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openDocumentViewer() {
        val intent = Intent(this, DocumentViewerActivity::class.java)
        startActivity(intent)
    }

    private fun showSettingsDialog() {
        val dialogBinding = DialogSettingsBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(this, R.style.Theme_FocusPhone_Dialog)
            .setView(dialogBinding.root)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val focusEnabled = whitelistManager.isFocusModeEnabled
        dialogBinding.switchFocusMode.isChecked = focusEnabled

        dialogBinding.switchFocusMode.setOnCheckedChangeListener { _, isChecked ->
            whitelistManager.isFocusModeEnabled = isChecked
            if (isChecked) {
                val serviceIntent = Intent(this, FocusForegroundService::class.java)
                startForegroundService(serviceIntent)
                Toast.makeText(this, "专注模式已开启", Toast.LENGTH_SHORT).show()
            } else {
                stopService(Intent(this, FocusForegroundService::class.java))
                Toast.makeText(this, "专注模式已关闭", Toast.LENGTH_SHORT).show()
            }
        }

        dialogBinding.btnManageApps.setOnClickListener {
            dialog.dismiss()
            showAppManagementDialog()
        }

        dialogBinding.btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialogBinding.btnDeactivate.setOnClickListener {
            dialog.dismiss()
            deactivateFocusMode()
        }

        dialog.show()
    }

    private fun showAppManagementDialog() {
        val pm = packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 || it.packageName == "com.tencent.mm" }
            .sortedBy { it.loadLabel(pm).toString() }

        val appNames = installedApps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val currentWhitelist = whitelistManager.getWhitelistedPackages()
        val checkedItems = BooleanArray(installedApps.size) { i ->
            currentWhitelist.contains(installedApps[i].packageName)
        }

        AlertDialog.Builder(this, R.style.Theme_FocusPhone_Dialog)
            .setTitle("管理白名单应用")
            .setMultiChoiceItems(appNames, checkedItems) { _, which, isChecked ->
                checkedItems[which] = isChecked
            }
            .setPositiveButton("确定") { _, _ ->
                val selected = mutableSetOf("com.focus.phone")
                installedApps.forEachIndexed { index, app ->
                    if (checkedItems[index]) {
                        selected.add(app.packageName)
                    }
                }
                whitelistManager.setWhitelistedPackages(selected)
                loadWhitelistedApps()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun deactivateFocusMode() {
        whitelistManager.isFocusModeEnabled = false
        stopService(Intent(this, FocusForegroundService::class.java))
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finish()
    }

    // RecyclerView Adapter
    inner class AppAdapter(
        private val apps: List<AppInfo>,
        private val onClick: (AppInfo) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.ivAppIcon)
            val name: TextView = view.findViewById(R.id.tvAppName)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = layoutInflater.inflate(R.layout.item_app, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val app = apps[position]
            holder.name.text = app.appName
            holder.icon.setImageDrawable(app.icon)
            holder.itemView.setOnClickListener { onClick(app) }
        }

        override fun getItemCount() = apps.size
    }

    override fun onBackPressed() {
        // Prevent going back from launcher
    }
}
