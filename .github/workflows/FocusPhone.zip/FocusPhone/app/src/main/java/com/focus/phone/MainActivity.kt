package com.focus.phone

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import com.focus.phone.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var whitelistManager: WhitelistManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        whitelistManager = WhitelistManager(this)

        if (whitelistManager.isSetupComplete && whitelistManager.isFocusModeEnabled) {
            startFocusMode()
            return
        }

        setupUI()
        updateStatusViews()
    }

    override fun onResume() {
        super.onResume()
        updateStatusViews()
    }

    private fun setupUI() {
        binding.btnPermissionAccessibility.setOnClickListener {
            openAccessibilitySettings()
        }

        binding.btnPermissionNotification.setOnClickListener {
            requestNotificationPermission()
        }

        binding.btnPermissionBattery.setOnClickListener {
            requestBatteryOptimizationExemption()
        }

        binding.btnPermissionOverlay.setOnClickListener {
            requestOverlayPermission()
        }

        binding.btnSelectApps.setOnClickListener {
            showAppSelectionDialog()
        }

        binding.btnSelectFolders.setOnClickListener {
            showFolderSelectionDialog()
        }

        binding.btnActivate.setOnClickListener {
            activateFocusMode()
        }
    }

    private fun updateStatusViews() {
        binding.statusAccessibility.text = if (isAccessibilityServiceEnabled()) "✅ 已开启" else "❌ 未开启"
        binding.statusNotification.text = if (NotificationManagerCompat.from(this).areNotificationsEnabled()) "✅ 已开启" else "❌ 未开启"
        binding.statusBattery.text = if (isBatteryOptimizationIgnored()) "✅ 已开启" else "❌ 未开启"
        binding.statusOverlay.text = if (Settings.canDrawOverlays(this)) "✅ 已开启" else "❌ 未开启"

        val whitelist = whitelistManager.getWhitelistedPackages()
        binding.statusApps.text = "已选 ${whitelist.size} 个应用"

        val folders = whitelistManager.getDocumentFolders()
        binding.statusFolders.text = "已选 ${folders.size} 个文件夹"

        val allReady = isAccessibilityServiceEnabled() &&
                NotificationManagerCompat.from(this).areNotificationsEnabled() &&
                isBatteryOptimizationIgnored()

        binding.btnActivate.isEnabled = allReady
        binding.btnActivate.alpha = if (allReady) 1.0f else 0.5f
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        return enabledServices.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun isBatteryOptimizationIgnored(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "请找到「专注模式」并开启", Toast.LENGTH_LONG).show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        NotificationManagerCompat.from(this).areNotificationsEnabled()
    }

    private fun requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun showAppSelectionDialog() {
        val pm = packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 || it.packageName == "com.tencent.mm" || it.packageName == "com.deepseek.app" }
            .sortedBy { it.loadLabel(pm).toString() }

        val appNames = installedApps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val currentWhitelist = whitelistManager.getWhitelistedPackages()
        val checkedItems = BooleanArray(installedApps.size) { i ->
            currentWhitelist.contains(installedApps[i].packageName)
        }

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("选择白名单应用")
            .setMultiChoiceItems(appNames, checkedItems) { _, which, isChecked ->
                checkedItems[which] = isChecked
            }
            .setPositiveButton("确定") { _, _ ->
                val selected = mutableSetOf("com.focus.phone")
                installedApps.forEachIndexed { index, app ->
                    if (checkedItems[index]) {
                        selected.add(app.packageName)
                    }
                }
                whitelistManager.setWhitelistedPackages(selected)
                updateStatusViews()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun showFolderSelectionDialog() {
        val folders = mutableListOf(
            "/sdcard/Documents",
            "/sdcard/Download",
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath
        ).distinct()

        val currentFolders = whitelistManager.getDocumentFolders()
        val checkedItems = BooleanArray(folders.size) { i ->
            currentFolders.contains(folders[i])
        }

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("选择文档文件夹")
            .setMultiChoiceItems(folders.toTypedArray(), checkedItems) { _, which, isChecked ->
                checkedItems[which] = isChecked
            }
            .setPositiveButton("确定") { _, _ ->
                val selected = mutableSetOf<String>()
                folders.forEachIndexed { index, folder ->
                    if (checkedItems[index]) {
                        selected.add(folder)
                    }
                }
                if (selected.isEmpty()) selected.add("/sdcard/Documents")
                whitelistManager.setDocumentFolders(selected)
                updateStatusViews()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun activateFocusMode() {
        whitelistManager.isFocusModeEnabled = true
        whitelistManager.isSetupComplete = true
        startFocusMode()
    }

    private fun startFocusMode() {
        val serviceIntent = Intent(this, FocusForegroundService::class.java)
        startForegroundService(serviceIntent)

        Toast.makeText(this, "专注模式已激活", Toast.LENGTH_SHORT).show()

        // Launch the custom launcher
        val launcherIntent = Intent(this, LauncherActivity::class.java)
        launcherIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(launcherIntent)
        finish()
    }
}
