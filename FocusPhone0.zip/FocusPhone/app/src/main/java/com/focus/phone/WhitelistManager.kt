package com.focus.phone

import android.content.Context
import android.content.SharedPreferences

class WhitelistManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isFocusModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_FOCUS_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_FOCUS_MODE, value).apply()

    var isSetupComplete: Boolean
        get() = prefs.getBoolean(KEY_SETUP_COMPLETE, false)
        set(value) = prefs.edit().putBoolean(KEY_SETUP_COMPLETE, value).apply()

    var isAccessibilityBlockingEnabled: Boolean
        get() = prefs.getBoolean(KEY_ACCESSIBILITY_BLOCKING, false)
        set(value) = prefs.edit().putBoolean(KEY_ACCESSIBILITY_BLOCKING, value).apply()

    fun getWhitelistedPackages(): Set<String> {
        return prefs.getStringSet(KEY_WHITELIST, defaultWhitelist()) ?: defaultWhitelist()
    }

    fun setWhitelistedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_WHITELIST, packages).apply()
    }

    fun addToWhitelist(packageName: String) {
        val current = getWhitelistedPackages().toMutableSet()
        current.add(packageName)
        setWhitelistedPackages(current)
    }

    fun removeFromWhitelist(packageName: String) {
        val current = getWhitelistedPackages().toMutableSet()
        current.remove(packageName)
        setWhitelistedPackages(current)
    }

    fun isWhitelisted(packageName: String): Boolean {
        return getWhitelistedPackages().contains(packageName)
    }

    fun getDocumentFolders(): Set<String> {
        return prefs.getStringSet(KEY_DOC_FOLDERS, defaultDocFolders()) ?: defaultDocFolders()
    }

    fun setDocumentFolders(folders: Set<String>) {
        prefs.edit().putStringSet(KEY_DOC_FOLDERS, folders).apply()
    }

    fun getDocumentFolderUris(): Set<String> {
        return prefs.getStringSet(KEY_DOC_FOLDER_URIS, emptySet()) ?: emptySet()
    }

    fun setDocumentFolderUris(uris: Set<String>) {
        prefs.edit().putStringSet(KEY_DOC_FOLDER_URIS, uris).apply()
    }

    private fun defaultWhitelist(): Set<String> {
        return setOf(
            "com.focus.phone",
            "com.tencent.mm",
            "com.deepseek.app"
        )
    }

    private fun defaultDocFolders(): Set<String> {
        return setOf("/sdcard/Documents")
    }

    companion object {
        private const val PREFS_NAME = "focus_phone_prefs"
        private const val KEY_WHITELIST = "whitelisted_packages"
        private const val KEY_FOCUS_MODE = "focus_mode_enabled"
        private const val KEY_SETUP_COMPLETE = "setup_complete"
        private const val KEY_DOC_FOLDERS = "document_folders"
        private const val KEY_DOC_FOLDER_URIS = "document_folder_uris"
        private const val KEY_ACCESSIBILITY_BLOCKING = "accessibility_blocking_enabled"
    }
}
