package com.focus.phone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val whitelistManager = WhitelistManager(context)
            if (whitelistManager.isFocusModeEnabled) {
                val serviceIntent = Intent(context, FocusForegroundService::class.java)
                context.startForegroundService(serviceIntent)
            }
        }
    }
}
