package com.focus.phone

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import com.focus.phone.databinding.ActivityDocumentViewerBinding
import java.io.File
import java.io.InputStream

class DocumentViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDocumentViewerBinding
    private lateinit var whitelistManager: WhitelistManager
    private var pdfRenderer: PdfRenderer? = null
    private var pageDescriptor: ParcelFileDescriptor? = null
    private var currentPageIndex = 0
    private var totalPages = 0
    private var currentFileUri: Uri? = null
    private var currentFileName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        whitelistManager = WhitelistManager(this)

        setupFileList()

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnRefresh.setOnClickListener {
            setupFileList()
        }
    }

    private fun setupFileList() {
        val files = mutableListOf<DocFileInfo>()
        val folderUris = whitelistManager.getDocumentFolderUris()

        for (uriString in folderUris) {
            try {
                val treeUri = Uri.parse(uriString)
                val docTree = DocumentFile.fromTreeUri(this, treeUri) ?: continue
                scanDirectory(docTree, files)
            } catch (e: Exception) {
                // Skip invalid URIs
            }
        }

        // Also scan common file paths as fallback
        val commonPaths = listOf(
            File("/sdcard/Documents"),
            File("/sdcard/Download")
        )
        for (path in commonPaths) {
            if (path.exists() && path.isDirectory) {
                val pathFiles = path.listFiles { file ->
                    file.isFile && (file.extension.lowercase() in listOf("pdf", "doc", "docx", "txt", "md"))
                }
                if (pathFiles != null) {
                    for (f in pathFiles) {
                        if (files.none { it.name == f.name }) {
                            files.add(DocFileInfo(f.name, f.length(), f.extension.lowercase(), Uri.fromFile(f), f))
                        }
                    }
                }
            }
        }

        files.sortByDescending { it.lastModified ?: 0L }

        if (files.isEmpty()) {
            binding.tvNoFiles.visibility = android.view.View.VISIBLE
            binding.recyclerFiles.visibility = android.view.View.GONE
        } else {
            binding.tvNoFiles.visibility = android.view.View.GONE
            binding.recyclerFiles.visibility = android.view.View.VISIBLE

            binding.recyclerFiles.layoutManager = LinearLayoutManager(this)
            binding.recyclerFiles.adapter = DocFileListAdapter(files) { fileInfo ->
                openFile(fileInfo)
            }
        }
    }

    private fun scanDirectory(dir: DocumentFile, files: MutableList<DocFileInfo>) {
        val children = dir.listFiles() ?: return
        for (child in children) {
            if (child.isDirectory) {
                scanDirectory(child, files)
            } else if (child.isFile) {
                val name = child.name ?: continue
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in listOf("pdf", "doc", "docx", "txt", "md")) {
                    files.add(DocFileInfo(name, child.length(), ext, child.uri, null))
                }
            }
        }
    }

    private fun openFile(fileInfo: DocFileInfo) {
        currentFileUri = fileInfo.uri
        currentFileName = fileInfo.name
        when (fileInfo.extension) {
            "pdf" -> openPdf(fileInfo)
            "doc", "docx" -> openWord(fileInfo)
            "txt", "md" -> openText(fileInfo)
            else -> Toast.makeText(this, "不支持的文件格式", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPdf(fileInfo: DocFileInfo) {
        // First try to open with external PDF viewer (WPS, Adobe, etc.)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileInfo.uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // No external PDF viewer, fall back to built-in renderer
            openPdfBuiltIn(fileInfo)
        }
    }

    private fun openPdfBuiltIn(fileInfo: DocFileInfo) {
        try {
            val pfd = contentResolver.openFileDescriptor(fileInfo.uri, "r") ?: return
            pageDescriptor = pfd
            pdfRenderer = PdfRenderer(pfd)
            totalPages = pdfRenderer!!.pageCount
            currentPageIndex = 0

            binding.pdfContainer.visibility = android.view.View.VISIBLE
            binding.recyclerFiles.visibility = android.view.View.GONE
            binding.tvNoFiles.visibility = android.view.View.GONE
            binding.pdfControls.visibility = android.view.View.VISIBLE

            renderPage(currentPageIndex)

            binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"

            binding.btnPrevPage.setOnClickListener {
                if (currentPageIndex > 0) {
                    currentPageIndex--
                    renderPage(currentPageIndex)
                    binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"
                }
            }

            binding.btnNextPage.setOnClickListener {
                if (currentPageIndex < totalPages - 1) {
                    currentPageIndex++
                    renderPage(currentPageIndex)
                    binding.tvPageInfo.text = "${currentPageIndex + 1} / $totalPages"
                }
            }

            binding.btnClosePdf.setOnClickListener {
                closePdf()
                binding.pdfContainer.visibility = android.view.View.GONE
                binding.pdfControls.visibility = android.view.View.GONE
                binding.recyclerFiles.visibility = android.view.View.VISIBLE
            }

            binding.tvPdfFileName.text = fileInfo.name

        } catch (e: Exception) {
            Toast.makeText(this, "无法打开PDF，请安装WPS等PDF阅读器", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderPage(index: Int) {
        pdfRenderer?.let { renderer ->
            val page = renderer.openPage(index)
            val density = resources.displayMetrics.density
            val width = (page.width * density).toInt()
            val height = (page.height * density).toInt()
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            binding.ivPdfPage.setImageBitmap(bitmap)
        }
    }

    private fun closePdf() {
        pdfRenderer?.close()
        pageDescriptor?.close()
        pdfRenderer = null
        pageDescriptor = null
    }

    private fun openWord(fileInfo: DocFileInfo) {
        val mime = when (fileInfo.extension) {
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "application/octet-stream"
        }

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileInfo.uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            extractTextFallback(fileInfo)
        }
    }

    private fun openText(fileInfo: DocFileInfo) {
        try {
            val inputStream = contentResolver.openInputStream(fileInfo.uri) ?: return
            val content = inputStream.bufferedReader().readText()
            inputStream.close()

            binding.textContainer.visibility = android.view.View.VISIBLE
            binding.recyclerFiles.visibility = android.view.View.GONE
            binding.tvNoFiles.visibility = android.view.View.GONE
            binding.tvTextContent.text = content
            binding.tvFileName.text = fileInfo.name

            binding.btnCloseText.setOnClickListener {
                binding.textContainer.visibility = android.view.View.GONE
                binding.recyclerFiles.visibility = android.view.View.VISIBLE
            }
        } catch (e: Exception) {
            Toast.makeText(this, "无法读取文件: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractTextFallback(fileInfo: DocFileInfo) {
        try {
            val inputStream = contentResolver.openInputStream(fileInfo.uri) ?: return
            val bytes = inputStream.readBytes()
            inputStream.close()

            val zipFile = java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes))
            var entry = zipFile.nextEntry
            var xmlContent: String? = null
            while (entry != null) {
                if (entry.name == "word/document.xml") {
                    xmlContent = zipFile.bufferedReader().readText()
                    break
                }
                entry = zipFile.nextEntry
            }
            zipFile.close()

            if (xmlContent != null) {
                val text = xmlContent.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
                binding.textContainer.visibility = android.view.View.VISIBLE
                binding.recyclerFiles.visibility = android.view.View.GONE
                binding.tvNoFiles.visibility = android.view.View.GONE
                binding.tvTextContent.text = text
                binding.tvFileName.text = fileInfo.name

                binding.btnCloseText.setOnClickListener {
                    binding.textContainer.visibility = android.view.View.GONE
                    binding.recyclerFiles.visibility = android.view.View.VISIBLE
                }
            } else {
                Toast.makeText(this, "无法提取文档内容，请安装WPS等办公应用", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "无法提取文档内容: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        closePdf()
    }
}

// Data class for document file info
data class DocFileInfo(
    val name: String,
    val size: Long,
    val extension: String,
    val uri: Uri,
    val file: File? = null,
    val lastModified: Long? = null
)

// File list adapter
class DocFileListAdapter(
    private val files: List<DocFileInfo>,
    private val onClick: (DocFileInfo) -> Unit
) : androidx.recyclerview.widget.RecyclerView.Adapter<DocFileListAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(view) {
        val tvName: android.widget.TextView = view.findViewById(R.id.tvFileName)
        val tvSize: android.widget.TextView = view.findViewById(R.id.tvFileSize)
        val tvType: android.widget.TextView = view.findViewById(R.id.tvFileType)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_file, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = files[position]
        holder.tvName.text = file.name
        holder.tvSize.text = formatFileSize(file.size)
        holder.tvType.text = file.extension.uppercase()
        holder.itemView.setOnClickListener { onClick(file) }
    }

    override fun getItemCount() = files.size

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> "${bytes / (1024 * 1024)} MB"
        }
    }
}
